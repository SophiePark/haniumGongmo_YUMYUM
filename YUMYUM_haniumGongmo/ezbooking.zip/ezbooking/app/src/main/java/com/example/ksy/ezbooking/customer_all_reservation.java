package com.example.ksy.ezbooking;

import android.app.ListActivity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by ksy on 16. 8. 23..
 */
public class customer_all_reservation extends ListActivity {
    private ArrayList reservation = new ArrayList();
    private String id;
    SQLiteDatabase db;
    DBhelper helper;

    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.actionbar,menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.action :
                Intent intent = new Intent(customer_all_reservation.this, mypage.class);
                Bundle data = new Bundle();
                data.putString("id",id);
                intent.putExtras(data);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        ListView listView;

        id = getIntent().getExtras().getString("id");
        // simple adapter test
        ArrayList<HashMap<String, String>> mlist = new ArrayList<HashMap<String, String>> ();


        super.onCreate(savedInstanceState);
        setContentView(R.layout.customer_all_reservation);



        helper = new DBhelper(this);

        try {
            db = helper.getWritableDatabase();

        } catch (SQLiteException e) {
            db = helper.getReadableDatabase();
        }


        Log.d("DD", "SELECT");

        Cursor c = db.rawQuery("SELECT num,date,approval FROM reservation where customer_id= ? ", new String[]{id});
        String date = "";
        String num = "";
        String approval = "";

        ArrayList<Reservation> R_list = new ArrayList<Reservation>();
        while(c.moveToNext()){
            num=c.getString(0);
            date=c.getString(1);
            approval=c.getString(2);
            reservation.add(num);
            if(approval.equals("yes")){
                num="[승인] "+num;
            }else if(approval.equals("no")){
                num="[비승인] "+num;
            }
            R_list.add(new Reservation(num,date));


        }ArrayList<HashMap<String, String>>mapList = new ArrayList<HashMap<String,String>>();
        for(Reservation r : R_list){

            HashMap  map  = new HashMap();
            System.out.println(r.r_num+","+r.r_date);

            map.put("num", r.r_num);

            map.put("date", r.r_date);

            mapList.add(map);

        }


        SimpleAdapter sap = new SimpleAdapter(this, mapList, android.R.layout.simple_list_item_2, new String[]{"num", "date"}, new int[]{android.R.id.text1, android.R.id.text2});
        setListAdapter(sap);
    }
    class Reservation{
        String r_num;
        String r_date;
        public Reservation(String r_num, String r_date){
            this.r_num = r_num;
            this.r_date = r_date;
        }
    }
    protected void onListItemClick(ListView l, View v, final int position, long id) {
        super.onListItemClick(l, v, position, id);
            final int number=position;
            String reservation_num= (String) reservation.get(number);
            Intent intent = new Intent(
                customer_all_reservation.this, // 현재 화면의 제어권자
                customer_reservation_detail.class);// 다음 넘어갈 클래스 지정
            intent.putExtra("reservationNum", reservation_num);//intent에 담아서 넘긴다
            intent.putExtra("id",id);
            startActivity(intent); // 다음 화면으로 넘어간다
            finish();
    }
}
