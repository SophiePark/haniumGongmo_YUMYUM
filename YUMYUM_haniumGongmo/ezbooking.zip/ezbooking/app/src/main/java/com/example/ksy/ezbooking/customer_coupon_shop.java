package com.example.ksy.ezbooking;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by ksy on 16. 9. 17..
 */
public class customer_coupon_shop extends AppCompatActivity {
    SQLiteDatabase db;
    DBhelper helper;

    private TextView my_onesoda, my_twosoda, my_fiveDC, my_tenDC;
    private Button button_onesoda, button_twosoda, button_fiveDC, button_tenDC, button_mypage,use_onesoda,use_twosoda,use_fiveDC,use_tenDC;
    private String id,onesoda,twosoda,fiveDC,tenDC;
    private Integer i_onesoda,i_twosoda,i_fiveDC,i_tenDC,point;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.customer_coupon_shop);

        helper = new DBhelper(this);
        try {
            db = helper.getWritableDatabase();
        } catch (SQLiteException e) {
            db = helper.getReadableDatabase();
        }

        Log.d("DD", "SELECT");

        id = getIntent().getExtras().getString("id");

        Cursor c = db.rawQuery("SELECT coupon,point FROM customer where id= ? ", new String[]{id});

        String coupon = "";


        while(c.moveToNext()) {
            coupon = c.getString(0);
            point=c.getInt(1);
        }

        onesoda = coupon.substring(0,1);
        twosoda = coupon.substring(1,2);
        fiveDC = coupon.substring(2,3);
        tenDC = coupon.substring(3, 4);
        i_onesoda=Integer.parseInt(onesoda);
        i_twosoda=Integer.parseInt(twosoda);
        i_fiveDC=Integer.parseInt(fiveDC);
        i_tenDC=Integer.parseInt(tenDC);

        my_onesoda=(TextView)findViewById(R.id.my_onesoda);
        my_onesoda.setText(onesoda);
        my_twosoda=(TextView)findViewById(R.id.my_twosoda);
        my_twosoda.setText(twosoda);
        my_fiveDC=(TextView)findViewById(R.id.my_fiveDC);
        my_fiveDC.setText(fiveDC);
        my_tenDC=(TextView)findViewById(R.id.my_tenDC);
        my_tenDC.setText(tenDC);

        button_mypage = (Button)findViewById(R.id.button_mypage);
        button_onesoda = (Button) findViewById(R.id.button_onesoda);
        button_twosoda = (Button) findViewById(R.id.button_twosoda);
        button_fiveDC = (Button) findViewById(R.id.button_fiveDC);
        button_tenDC = (Button) findViewById(R.id.button_tenDC);
        use_onesoda = (Button) findViewById(R.id.use_onesoda);
        use_twosoda = (Button) findViewById(R.id.use_twosoda);
        use_fiveDC = (Button) findViewById(R.id.use_fiveDC);
        use_tenDC = (Button) findViewById(R.id.use_tenDC);

        button_mypage.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(
                        customer_coupon_shop.this, // 현재 화면의 제어권자
                        mypage.class);
                intent.putExtra("id",id);
                startActivity(intent);
                finish();
            }
        });
        button_onesoda.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                checkOkDialog(1);
            }
        });
        button_twosoda.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                checkOkDialog(2);
            }
        });
        button_fiveDC.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                checkOkDialog(3);
            }
        });
        button_tenDC.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                checkOkDialog(4);
            }
        });

        use_onesoda.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                if(i_onesoda==0){
                    Toast.makeText(customer_coupon_shop.this, "사용할 쿠폰이 없습니다.", Toast.LENGTH_SHORT).show();

                }else{
                    useDialog(1);
                }
            }
        });
        use_twosoda.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                if(i_twosoda==0){
                    Toast.makeText(customer_coupon_shop.this, "사용할 쿠폰이 없습니다.", Toast.LENGTH_SHORT).show();

                }else{
                    useDialog(2);
                }
            }
        });
        use_fiveDC.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                if(i_fiveDC==0){
                    Toast.makeText(customer_coupon_shop.this, "사용할 쿠폰이 없습니다.", Toast.LENGTH_SHORT).show();

                }else{
                    useDialog(3);
                }
            }
        });
        use_tenDC.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                if(i_tenDC==0){
                    Toast.makeText(customer_coupon_shop.this, "사용할 쿠폰이 없습니다.", Toast.LENGTH_SHORT).show();

                }else{
                    useDialog(4);
                }
            }
        });
    }
    private void use_coupon(int i){
        if(i==1){
            i_onesoda-=1;
            onesoda=Integer.toString(i_onesoda);
            my_onesoda.setText(onesoda);
            String newcoupon = onesoda+twosoda+fiveDC+tenDC;
            db.execSQL("UPDATE customer SET coupon = ? WHERE id =?", new Object[]{newcoupon,id});


        }else if(i==2){
            i_twosoda-=1;
            twosoda=Integer.toString(i_twosoda);
            my_twosoda.setText(twosoda);
            String newcoupon = onesoda+twosoda+fiveDC+tenDC;
            db.execSQL("UPDATE customer SET coupon = ? WHERE id =?", new Object[]{newcoupon,id});

        }else if(i==3){
            i_fiveDC-=1;
            fiveDC=Integer.toString(i_fiveDC);
            my_fiveDC.setText(fiveDC);
            String newcoupon = onesoda+twosoda+fiveDC+tenDC;
            db.execSQL("UPDATE customer SET coupon = ? WHERE id =?", new Object[]{newcoupon,id});

        }else{
            i_tenDC-=1;
            tenDC=Integer.toString(i_tenDC);
            my_tenDC.setText(tenDC);
            String newcoupon = onesoda+twosoda+fiveDC+tenDC;
            db.execSQL("UPDATE customer SET coupon = ? WHERE id =?", new Object[]{newcoupon,id});

        }
    }
    private void Buy_coupon_Check(int i){
        if(i==1){
            i_onesoda+=1;
            onesoda=Integer.toString(i_onesoda);
            my_onesoda.setText(onesoda);
            String newcoupon = onesoda+twosoda+fiveDC+tenDC;
            db.execSQL("UPDATE customer SET coupon = ? WHERE id =?", new Object[]{newcoupon,id});
            db.execSQL("UPDATE customer SET point = ? WHERE id =?", new Object[]{point-500,id});


        }else if(i==2){
            i_twosoda+=1;
            twosoda=Integer.toString(i_twosoda);
            my_twosoda.setText(twosoda);
            String newcoupon = onesoda+twosoda+fiveDC+tenDC;
            db.execSQL("UPDATE customer SET coupon = ? WHERE id =?", new Object[]{newcoupon,id});
            db.execSQL("UPDATE customer SET point = ? WHERE id =?", new Object[]{point-1000,id});


        }else if(i==3){
            i_fiveDC+=1;
            fiveDC=Integer.toString(i_fiveDC);
            my_fiveDC.setText(fiveDC);
            String newcoupon = onesoda+twosoda+fiveDC+tenDC;
            db.execSQL("UPDATE customer SET coupon = ? WHERE id =?", new Object[]{newcoupon, id});
            db.execSQL("UPDATE customer SET point = ? WHERE id =?", new Object[]{point-1000,id});



        }else if(i==4){
            i_tenDC+=1;
            tenDC=Integer.toString(i_tenDC);
            my_tenDC.setText(tenDC);
            String newcoupon = onesoda+twosoda+fiveDC+tenDC;
            db.execSQL("UPDATE customer SET coupon = ? WHERE id =?", new Object[]{newcoupon, id});
            db.execSQL("UPDATE customer SET point = ? WHERE id =?", new Object[]{point-1500,id});

        }
    }
    private void useDialog(final int i){
        AlertDialog.Builder reservationConfirm = new AlertDialog.Builder(customer_coupon_shop.this);
        reservationConfirm.setTitle("사용 여부 확인");
        final String checkMsg = "쿠폰을 사용하시겠습니까? (쿠폰 사용은 반드시 가게 직원에게 확인 후 선택하시기 바랍니다)";
        reservationConfirm.setMessage(checkMsg).setCancelable(false).setPositiveButton("사용",new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {// 'YES'
                use_coupon(i);
                Toast.makeText(customer_coupon_shop.this, "사용되었습니다.", Toast.LENGTH_SHORT).show();

            }
        }).setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {// 'No'
                Toast.makeText(customer_coupon_shop.this,"취소되었습니다.",Toast.LENGTH_SHORT).show();

                return;
            }
        });
        AlertDialog alert = reservationConfirm.create();
        alert.show();
    }
    private void checkOkDialog(final int i){//예약내용 확인받기
        AlertDialog.Builder reservationConfirm = new AlertDialog.Builder(customer_coupon_shop.this);
        reservationConfirm.setTitle("구매 여부 확인");
        final String checkMsg = "구매 시 포인트가 차감됩니다. 계속하시겠습니까?";
        reservationConfirm.setMessage(checkMsg).setCancelable(false).setPositiveButton("확인",new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {// 'YES'
                Buy_coupon_Check(i);
                Toast.makeText(customer_coupon_shop.this, "구매되었습니다.", Toast.LENGTH_SHORT).show();

            }
        }).setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {// 'No'
                Toast.makeText(customer_coupon_shop.this,"취소되었습니다.",Toast.LENGTH_SHORT).show();

                return;
            }
        });
        AlertDialog alert = reservationConfirm.create();
        alert.show();
    }
}