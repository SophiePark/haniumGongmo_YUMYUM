package com.example.ksy.ezbooking;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.view.View;


/**
 * Created by SOPHIE on 2016. 7. 31..
 */
public class mypage extends AppCompatActivity {

    SQLiteDatabase db;
    DBhelper helper;

    private TextView myPageTitle, customerId, myFame, myPointTitle,myPoint,myName;
    private Button b_goSearch,b_myCoupon,b_allReservation;
    private String id;
    public static boolean isRunning = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.mypage);
        isRunning = true;

        helper = new DBhelper(this);
        try {
            db = helper.getWritableDatabase();
        } catch (SQLiteException e) {
            db = helper.getReadableDatabase();
        }
        Log.d("DD", "SELECT");

        id = getIntent().getExtras().getString("id");

        Cursor c = db.rawQuery("SELECT name,fame,point FROM customer where id= ? ", new String[]{id});

        String name = "";
        int fame = 0;
        int point = 0;

        while(c.moveToNext()) {
            name = c.getString(0);
            fame = c.getInt(1);
            point = c.getInt(2);
        }

        myPageTitle = (TextView) findViewById(R.id.myPageTitle);
        myPageTitle.setText("마이페이지 >");

        customerId = (TextView) findViewById(R.id.customerId);
        customerId.setText(id);

        myFame = (TextView) findViewById(R.id.myFAME);
        myFame.setText(calculateFame(fame)+"FAME");

        myPointTitle =(TextView) findViewById(R.id.myPointTitle);
        myPointTitle.setText("POINT");

        myPoint = (TextView) findViewById(R.id.myPoint);
        myPoint.setText(point+" 점");

        myName = (TextView) findViewById(R.id.myName);
        myName.setText(name+"님");

        b_goSearch = (Button) findViewById(R.id.goSearch);
        b_myCoupon = (Button) findViewById(R.id.myCoupon);
        b_allReservation = (Button) findViewById(R.id.all_reservation);


        b_goSearch.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){
                Intent intent = new Intent(mypage.this, SelectFirst.class);
                Bundle data = new Bundle();
                data.putString("id",id);
                intent.putExtras(data);
                startActivity(intent);
            }
        });

        b_myCoupon.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){
                Intent intent = new Intent(mypage.this, customer_coupon_shop.class);
                Bundle data = new Bundle();
                data.putString("id",id);
                intent.putExtras(data);
                startActivity(intent);
                finish();
            }
        });

        b_allReservation.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){
                Intent intent = new Intent(mypage.this, customer_all_reservation.class);
                Bundle data = new Bundle();
                data.putString("id",id);
                intent.putExtras(data);
                startActivity(intent);
            }
        });
    }

    public int calculateFame(int fame){
        int Fame = 0;
        if (fame > 9)
            Fame = 5;
        else if (6 <fame)
            Fame = 4;
        else if (3 <fame)
            Fame = 3;
        else if (1<fame)
            Fame = 2;
        else
            Fame = 1;
        return Fame;
    }
}
