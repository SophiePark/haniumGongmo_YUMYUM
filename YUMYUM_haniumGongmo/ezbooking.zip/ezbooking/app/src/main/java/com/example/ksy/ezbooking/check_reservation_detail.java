package com.example.ksy.ezbooking;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.view.View;
import android.widget.Toast;

import java.util.Calendar;

/**
 * Created by SOPHIE on 2016. 8. 12..
 */
public class check_reservation_detail extends AppCompatActivity {

    private TextView Title,ReserDate, ReserTime, ReserNum, ReserName, ReserPhoneNum, ReserMany, ReserMemo,ReserFame, ReserNoShow, ReserApproval;
    private TextView detail_ReserDate, detail_ReserTime, detail_ReserNum, detail_ReserName, detail_ReserPhoneNum, detail_ReserMany, detail_ReserMemo,detail_ReserFame,detail_ReserNoShow, detail_ReserApproval;
    private Button b_ok, b_NoShow,b_end;
    SQLiteDatabase db;
    DBhelper helper;
    private String reservation_num,customer_id,r_id;
    private int mYear, mMonth,mDay,mTotal,mDate,no_show,point;
    private String STotal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.check_reservation_detail);
        reservation_num = getIntent().getExtras().getString("input_reservation");
        r_id = getIntent().getExtras().getString("r_id");
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH)+1;
        mDay = c.get(Calendar.DATE);

        String sYear = Integer.toString(mYear);
        String sMonth="";
        if(mMonth>=10) {
            sMonth = Integer.toString(mMonth);
        }if(mMonth<10){
            sMonth = "0"+Integer.toString(mMonth);
        }
        String sDay = "";
        if(mDay>=10){
            sDay=Integer.toString(mDay);
        }if(mDay<10){
            sDay="0"+Integer.toString(mDay);
        }
        STotal = sYear+sMonth+sDay;
        mTotal = Integer.parseInt(STotal);
        helper = new DBhelper(this);

        try {
            db = helper.getWritableDatabase();

        } catch (SQLiteException e) {
            db = helper.getReadableDatabase();
        }

        Title = (TextView) findViewById(R.id.ReservationDetailTitle);
        Title.setText("예약상세정보");
        ReserDate = (TextView) findViewById(R.id.ReserDate);
        ReserDate.setText("예약날짜");
        ReserTime = (TextView) findViewById(R.id.ReserTime);
        ReserTime.setText("예약시간");
        ReserNum = (TextView) findViewById(R.id.ReserNum);
        ReserNum.setText("예약번호");
        ReserName = (TextView) findViewById(R.id.ReserName);
        ReserName.setText("예약자");
        ReserPhoneNum = (TextView) findViewById(R.id.ReserPhoneNum);
        ReserPhoneNum.setText("전화번호");
        ReserMany = (TextView) findViewById(R.id.ReserMany);
        ReserMany.setText("예약인원");
        ReserMemo = (TextView) findViewById(R.id.ReserMemo);
        ReserMemo.setText("예약메모");
        ReserFame= (TextView) findViewById(R.id.ReserFame);
        ReserFame.setText("고객등급");
        ReserNoShow = (TextView) findViewById(R.id.ReserNoshow);
        ReserNoShow.setText("NOSHOW");
        ReserApproval = (TextView) findViewById(R.id.ReserApproval);
        ReserApproval.setText("승인여부");

        detail_ReserDate = (TextView) findViewById(R.id.detail_ReserDate);
        detail_ReserTime = (TextView) findViewById(R.id.detail_ReserTime);
        detail_ReserNum = (TextView) findViewById(R.id.detail_ReserNum);
        detail_ReserName = (TextView) findViewById(R.id.detail_ReserName);
        detail_ReserPhoneNum = (TextView) findViewById(R.id.detail_ReserPhoneNum);
        detail_ReserMany = (TextView) findViewById(R.id.detail_ReserMany);
        detail_ReserMemo = (TextView) findViewById(R.id.detail_ReserMemo);
        detail_ReserFame = (TextView) findViewById(R.id.detail_ReserFame);
        detail_ReserNoShow = (TextView) findViewById(R.id.detail_ReserNoShow);
        detail_ReserApproval = (TextView) findViewById(R.id.detail_ReserApproval);

        Log.d("DD", "SELECT");

        Cursor cursor = db.rawQuery("SELECT date,time,customer_id,persons_num,memo,approval,no_show FROM reservation where num= ? ", new String[]{reservation_num});
        String date = "";
        String time = "";
        Integer per_num=0;
        String menu="";
        String approval="";
        String noShow = "";

        while (cursor.moveToNext()) {
            date = cursor.getString(0);
            time = cursor.getString(1);
            customer_id=cursor.getString(2);
            per_num=cursor.getInt(3);
            menu=cursor.getString(4);
            approval=cursor.getString(5);
            noShow = cursor.getString(6);

        }
        String s_per_num = Integer.toString(per_num);

        Log.d("DD", "SELECT");

        Cursor d = db.rawQuery("SELECT phone,point,fame FROM customer where id= ? ", new String[]{customer_id});
        String phone="";
        int fame=0;
        point=0;

        while(d.moveToNext()){
            phone=d.getString(0);
            point=d.getInt(1);
            fame=d.getInt(2);
        }

        detail_ReserDate.setText(date);
        detail_ReserTime.setText(time);
        detail_ReserNum.setText(reservation_num);
        detail_ReserName.setText(customer_id);
        detail_ReserPhoneNum.setText(phone);
        detail_ReserMany.setText(s_per_num);
        detail_ReserMemo.setText(menu);
        detail_ReserFame.setText(calculateFame(fame)+" FAME");
        detail_ReserNoShow.setText(noShow);
        detail_ReserApproval.setText(approval);
        mDate = Integer.parseInt(date);
        b_ok = (Button) findViewById(R.id.b_ok);
        b_NoShow = (Button) findViewById(R.id.b_NoShow);
        b_end=(Button)findViewById(R.id.b_end);

        b_end.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(
                        check_reservation_detail.this, // 현재 화면의 제어권자
                        restaurant_all_reservation.class);
                intent.putExtra("r_id",r_id);
                startActivity(intent);
                finish();
            }
        });
        b_ok.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                CheckApprovalDialog();

            }
        });

        b_NoShow.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (mDate > mTotal) {
                    Toast.makeText(getApplicationContext(), "예약날짜("+mDate+") 이후부터 No Show 체크 가능!", Toast.LENGTH_SHORT).show();
                }else{
                    checkOkDialog();
                }
            }
        });


    }

    private void CheckApprovalDialog(){
        AlertDialog.Builder checkApproval = new AlertDialog.Builder(check_reservation_detail.this);
        checkApproval.setTitle("안내");
        final String checkMsg = "해당 예약의 승인여부를 결정해주세요.";
        checkApproval.setMessage(checkMsg).setCancelable(false).setPositiveButton("승인",new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {// 'YES'
                approvalOK();
                Toast.makeText(check_reservation_detail.this,"예약이 승인되었습니다.",Toast.LENGTH_SHORT).show();

            }
        }).setNegativeButton("거절", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {// 'No'
                approvalNO();
                Toast.makeText(check_reservation_detail.this,"예약이 거절되었습니다.",Toast.LENGTH_SHORT).show();
                return;
            }
        });
        AlertDialog alert = checkApproval.create();
        alert.show();
    }

    private void NoShowCheck(){
        Log.d("DD", "SELECT");

        Cursor d = db.rawQuery("SELECT fame FROM customer where id= ? ", new String[]{customer_id});
        while(d.moveToNext()){
            no_show=d.getInt(0);
        }
        Integer newNoshow = no_show+1;

        String sql = "update customer set fame = " + newNoshow +" where id = '"+customer_id +"';";
        db.execSQL(sql);
        String sql3 = "update reservation set no_show = 'yes' where num = '"+reservation_num +"';";
        db.execSQL(sql3);
        detail_ReserNoShow.setText("yes");
    }
    private void ShowCheck(){
        Log.d("DD", "SELECT");
        db.execSQL("UPDATE customer SET point = ? WHERE id =?", new Object[]{point+500,customer_id});
        db.execSQL("DELETE FROM reservation WHERE num = ?",new String[]{reservation_num});
        detail_ReserNoShow.setText("no");
    }

    private void checkOkDialog(){
        AlertDialog.Builder checkOk= new AlertDialog.Builder(check_reservation_detail.this);
        checkOk.setTitle("안내");
        final String checkMsg = "해당 예약의 NoShow 여부를 확인해주세요.\nNOSHOW 체크 시 고객의 fame 등급이 내려갑니다.";
        checkOk.setMessage(checkMsg).setCancelable(false).setPositiveButton("NOSHOW",new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {// 'YES'
                NoShowCheck();
                Toast.makeText(check_reservation_detail.this,"NoShow가 체크되었습니다.",Toast.LENGTH_SHORT).show();

            }
        }).setNegativeButton("SHOW", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {// 'No'
                ShowCheck();
                Toast.makeText(check_reservation_detail.this,"해당예약건이 완료되었습니다.",Toast.LENGTH_SHORT).show();

                return;
            }
        });
        AlertDialog alert = checkOk.create();
        alert.show();
    }
    private void approvalOK(){
        String sql = "update reservation set approval = 'yes' where num = '"+reservation_num +"';";
        db.execSQL(sql);
        detail_ReserApproval.setText("yes");
    }
    private void approvalNO(){
        String sql = "update reservation set approval = 'no' where num = '"+reservation_num +"';";
        db.execSQL(sql);
        detail_ReserApproval.setText("no");
    }

    public int calculateFame(int fame){
        int Fame = 0;
        if (fame > 9)
            Fame = 5;
        else if (6 <fame)
            Fame = 4;
        else if (3 <fame)
            Fame = 3;
        else if (1<fame)
            Fame = 2;
        else
            Fame = 1;
        return Fame;
    }

}


